# WA Trading Intelligence Platform
## Complete Deployment & Handover Guide
### Prepared for: Pro Tech Trading FZCO

---

## OVERVIEW

This is a full-stack web application that connects to WhatsApp trading groups via Whapi.Cloud, analyzes messages using Claude AI, and provides a business intelligence dashboard for electronics wholesale trading.

**What the app does:**
- Connects multiple WhatsApp numbers and selected groups
- Auto-extracts listings: WTS/WTB, model, specs, color, grade, price, seller country
- AI deal scoring (1-10) on every listing
- Fake listing detection
- Market intelligence: demand vs supply, price tracking, hot items
- Deal pipeline management (New → Contacted → Negotiating → Done)
- Team management with role-based access
- Export sellers/buyers to Excel with one tap
- AI tools: market briefing, price advisor, trader profiler, auto-reply drafts
- Margin & profit calculator with price alerts
- Works as a mobile app on iPhone/iPad (add to home screen)

---

## FILES INCLUDED

```
wa-trading-app/
├── server.js          ← Backend server (Node.js)
├── package.json       ← Dependencies
├── railway.toml       ← Deployment config
└── public/
    └── index.html     ← Full frontend app
```

---

## STEP 1 — ACCOUNTS TO CREATE (all free)

The developer needs to create accounts on these services:

### A. Render.com (hosting — free tier)
- Go to: https://render.com
- Sign up with Google or email
- This is where the app will be deployed and hosted
- Free tier is sufficient to start

### B. MongoDB Atlas (database — free tier)
- Go to: https://www.mongodb.com/atlas
- Sign up free
- This stores all listing data permanently
- Free tier (M0) gives 512MB — enough for thousands of listings

### C. Anthropic Console (AI — pay as you use)
- Go to: https://console.anthropic.com
- Sign up and add a payment method
- Get API key — used for AI features (deal scoring, market briefing, price advisor)
- Cost is very low — roughly $1-5/month for typical usage

### D. Whapi.Cloud (WhatsApp connector — already set up)
- Account already created: ayousif@gmail.com
- Free trial channel already activated: WOLVRN-FE2AK
- Still needs: WhatsApp QR scan to link the number
- After trial: $35/month per WhatsApp number connected

---

## STEP 2 — SET UP MONGODB ATLAS

1. Log into mongodb.com/atlas
2. Click **"Build a Database"**
3. Choose **FREE** tier (M0 Sandbox)
4. Select region: closest to UAE (e.g. AWS Frankfurt or Mumbai)
5. Click **"Create"**
6. **Create database user:**
   - Username: `watrading`
   - Password: create a strong password — **save this password**
   - Click "Create User"
7. **Network access:**
   - Click "Add IP Address"
   - Click "Allow Access from Anywhere" (0.0.0.0/0)
   - Click "Confirm"
8. **Get connection string:**
   - Click "Connect" on your cluster
   - Choose "Connect your application"
   - Copy the connection string — looks like:
   ```
   mongodb+srv://watrading:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
   - Replace `<password>` with the password you created
   - Add database name before `?`:
   ```
   mongodb+srv://watrading:YOURPASSWORD@cluster0.xxxxx.mongodb.net/wa_trading?retryWrites=true&w=majority
   ```
   - **Save this full string — you will need it**

---

## STEP 3 — GET CLAUDE API KEY

1. Go to: https://console.anthropic.com
2. Sign up / log in
3. Go to **API Keys** section
4. Click **"Create Key"**
5. Name it: `wa-trading-platform`
6. Copy the key — starts with `sk-ant-`
7. **Save this key — it only shows once**
8. Add a credit card (billing) — charges are minimal, roughly $1-5/month

---

## STEP 4 — DEPLOY ON RENDER.COM

### 4A. Prepare the ZIP file
- Take the provided `wa-trading-app` folder
- Zip it into: `wa-trading-app.zip`
- Make sure the structure inside the zip is:
  ```
  server.js
  package.json
  railway.toml
  public/index.html
  ```

### 4B. Create Web Service on Render
1. Log into render.com
2. Click **"New +"** → **"Web Service"**
3. Choose **"Deploy an existing image or upload files"**
   - If that option is not available, use GitHub:
   - Create free GitHub account at github.com
   - Create new repository named `wa-trading-app`
   - Upload the 4 files (server.js, package.json, railway.toml, public/index.html)
   - In Render: choose "Connect a repository" → select your repo

### 4C. Configure the service
- **Name:** `wa-trading-app`
- **Region:** Frankfurt (EU) or Singapore (closest to UAE)
- **Branch:** main
- **Build Command:** `npm install`
- **Start Command:** `node server.js`
- **Instance Type:** Free

### 4D. Add Environment Variables
In Render → your service → **Environment** tab → Add these:

| Key | Value |
|-----|-------|
| `CLAUDE_API_KEY` | Your Claude API key (sk-ant-...) |
| `MONGO_URI` | Your MongoDB connection string |
| `JWT_SECRET` | Any random string e.g. `watrading-secret-2024-xyz` |
| `PORT` | `3000` |

### 4E. Deploy
- Click **"Create Web Service"**
- Wait 3-5 minutes for deployment
- Render gives you a URL like: `https://wa-trading-app.onrender.com`
- **Save this URL**

### 4F. Verify deployment
- Open the URL in a browser
- Go to: `https://wa-trading-app.onrender.com/health`
- You should see:
  ```json
  {"status":"ok","listings":0,"db":"mongodb"}
  ```
- If db shows "memory" instead of "mongodb" — check your MONGO_URI variable

---

## STEP 5 — CONNECT WHATSAPP VIA WHAPI

### 5A. Link WhatsApp number
1. Go to: https://panel.whapi.cloud
2. Log in with: ayousif@gmail.com
3. Click on channel **WOLVRN-FE2AK**
4. A QR code will appear
5. On the WhatsApp phone:
   - Open WhatsApp
   - Go to **Settings → Linked Devices → Link a Device**
   - Scan the QR code
6. The number is now connected

### 5B. Get API Token
1. In Whapi dashboard → your channel
2. Find **API Token** or **Token** section
3. Copy the token — save it

### 5C. Set up Webhook
1. In Whapi dashboard → your channel → **Settings → Webhooks**
2. Add webhook URL:
   ```
   https://wa-trading-app.onrender.com/webhook?channel=ch_main
   ```
   *(Replace `ch_main` with any ID you want for this number)*
3. Enable event: **messages.upsert**
4. Save

---

## STEP 6 — CONFIGURE THE APP

1. Open the app URL in Safari on iPhone/iPad:
   `https://wa-trading-app.onrender.com`

2. **Register first account:**
   - Click "Register"
   - Enter name, company (Pro Tech Trading FZCO), email, password
   - First account created is automatically **Admin**

3. **Add WhatsApp channel:**
   - Go to **📱 Channels** tab
   - Enter label: "Main Number" (or whatever the number is)
   - Enter the Whapi API token you copied
   - Click **"Add WhatsApp Number"**

4. **Fetch and select groups:**
   - Click **"🔄 Fetch Groups"** on the channel
   - All WhatsApp groups the number is in will appear
   - Toggle **ON** the trading groups you want to track
   - Toggle **OFF** personal/family groups

5. **Copy webhook URL:**
   - Each channel shows its unique webhook URL
   - Copy it
   - Go back to Whapi → Webhooks → update with this URL

---

## STEP 7 — ADD TO IPHONE/IPAD HOME SCREEN

On each iPhone or iPad:
1. Open Safari (must be Safari, not Chrome)
2. Go to: `https://wa-trading-app.onrender.com`
3. Tap the **Share button** (box with arrow)
4. Scroll down → tap **"Add to Home Screen"**
5. Name it: "WA Trading"
6. Tap **"Add"**
7. App icon appears on home screen — works like a native app

---

## STEP 8 — INVITE TEAM MEMBERS

1. Share the app URL with team members
2. They register their own accounts
3. Admin can see all team members in the **🏢 Team** tab
4. Listings can be assigned to specific team members
5. Each member sees the full pipeline and can update status

---

## APP FEATURES GUIDE

### Feed Tab (📋)
- All incoming WhatsApp listings in real time
- Each listing shows: WTS/WTB, Brand New/Used, model, specs, color, grade, price, seller country flag
- Deal Score (⭐1-10) — AI rates each deal automatically
- ⚠️ Flag — AI marks suspicious/fake listings
- **Pipeline buttons:** New → Contacted → Negotiating → Done → Pass
- **Assign** listing to a team member
- **💬 WhatsApp** button — opens direct chat with seller
- **📞 Call** button — dials seller
- **🤖 AI Reply** — drafts a professional WhatsApp reply

### Market Tab (🔥)
- Demand vs Supply heatmap per model
- 🔥 HOT = more buyers than sellers
- 📦 OVER = too many sellers, price dropping
- Price tracker: min/avg/max per model

### AI Tab (🤖)
- **Daily Briefing** — AI summary of today's market
- **Price Advisor** — fair market price for any device
- **Trader Profiler** — full profile of any trader by number
- **Item Intelligence** — ask anything about any device

### Margin Calculator (💰)
- Enter buy price, sell price, qty, shipping, duty
- Instant profit, margin %, ROI calculation
- Set price alerts — get notified when any listing matches

### Export Tab (📤)
- Filter by item name
- Export WTS sellers or WTB buyers to Excel
- Excel includes: name, phone, WhatsApp link, model, specs, price, country
- Full market report export with demand analysis

### Channels Tab (📱)
- Add multiple WhatsApp numbers
- Fetch and manage groups per number
- Toggle individual groups on/off
- Each number has its own webhook URL

---

## IMPORTANT NOTES FOR DEVELOPER

1. **Free tier limitation on Render:** The free tier "spins down" after 15 minutes of inactivity. First request after inactivity takes ~30 seconds. Upgrade to Starter plan ($7/month) to keep it always on.

2. **MongoDB Atlas free tier:** 512MB storage, enough for ~100,000 listings. Monitor usage in Atlas dashboard.

3. **Whapi trial:** Free trial has message limits. After trial ends, upgrade to paid plan ($35/month per number).

4. **Claude API costs:** Very low. Deal scoring runs on every message — estimate $2-5/month for typical group activity.

5. **JWT_SECRET:** This is used to sign login tokens. Choose a long random string and never change it after launch (it will log everyone out).

6. **Multiple WhatsApp numbers:** Each additional number needs its own Whapi channel (+$35/month each). Add as many as needed in the 📱 Channels tab.

7. **Data persistence:** All listing data is stored in MongoDB. The app also uses browser localStorage as a cache. Data survives server restarts.

8. **Security:** The app uses JWT authentication. All API endpoints require login. Do not expose the server without authentication.

---

## ENVIRONMENT VARIABLES SUMMARY

| Variable | Description | Example |
|----------|-------------|---------|
| `CLAUDE_API_KEY` | Anthropic API key | `sk-ant-api03-...` |
| `MONGO_URI` | MongoDB connection string | `mongodb+srv://user:pass@cluster.mongodb.net/wa_trading` |
| `JWT_SECRET` | Login token secret | `watrading-secret-2024-xyz` |
| `PORT` | Server port (Render sets this) | `3000` |

---

## CONTACTS & ACCOUNTS SUMMARY

| Service | URL | Account | Notes |
|---------|-----|---------|-------|
| Whapi.Cloud | panel.whapi.cloud | ayousif@gmail.com | Trial active, channel WOLVRN-FE2AK |
| Render.com | render.com | Create new | Free hosting |
| MongoDB Atlas | mongodb.com/atlas | Create new | Free database |
| Anthropic | console.anthropic.com | Create new | AI features |

---

## ESTIMATED MONTHLY COSTS (after trial)

| Service | Cost |
|---------|------|
| Render (Starter — always on) | $7/month |
| MongoDB Atlas (free tier) | $0/month |
| Whapi.Cloud (1 number) | $35/month |
| Claude API (AI features) | ~$3-5/month |
| **Total** | **~$45-47/month** |

---

## SUPPORT

If anything is unclear or not working:
- Render docs: https://render.com/docs
- MongoDB Atlas docs: https://www.mongodb.com/docs/atlas
- Whapi docs: https://support.whapi.cloud/help-desk/getting-started/getting-started
- Anthropic docs: https://docs.anthropic.com

---

*Document prepared by Claude AI for Pro Tech Trading FZCO*
*App version: 2.0 — Full Business Edition*
